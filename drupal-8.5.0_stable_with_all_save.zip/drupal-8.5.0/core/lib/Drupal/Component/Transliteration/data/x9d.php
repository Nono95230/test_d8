<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'fou', 'yao', 'jue', 'jue', 'pi', 'huan', 'zhen', 'bao', 'yan', 'ya', 'zheng', 'fang', 'feng', 'wen', 'ou', 'dai',
  0x10 => 'ge', 'ru', 'ling', 'mie', 'fu', 'tuo', 'min', 'li', 'bian', 'zhi', 'ge', 'yuan', 'ci', 'qu', 'xiao', 'chi',
  0x20 => 'dan', 'ju', 'yao', 'gu', 'dong', 'yu', 'yang', 'rong', 'ya', 'tie', 'yu', 'tian', 'ying', 'dui', 'wu', 'er',
  0x30 => 'gua', 'ai', 'zhi', 'yan', 'heng', 'xiao', 'jia', 'lie', 'zhu', 'yang', 'ti', 'hong', 'luo', 'ru', 'mou', 'ge',
  0x40 => 'ren', 'jiao', 'xiu', 'zhou', 'zhi', 'luo', 'heng', 'nian', 'e', 'luan', 'jia', 'ji', 'tu', 'huan', 'tuo', 'bu',
  0x50 => 'wu', 'juan', 'yu', 'bo', 'jun', 'xun', 'bi', 'xi', 'jun', 'ju', 'tu', 'jing', 'ti', 'e', 'e', 'kuang',
  0x60 => 'hu', 'wu', 'shen', 'lai', 'jiao', 'pan', 'lu', 'pi', 'shu', 'fu', 'an', 'zhuo', 'peng', 'qin', 'qian', 'bei',
  0x70 => 'diao', 'lu', 'que', 'jian', 'ju', 'tu', 'ya', 'yuan', 'qi', 'li', 'ye', 'zhui', 'kong', 'duo', 'kun', 'sheng',
  0x80 => 'qi', 'jing', 'yi', 'yi', 'jing', 'zi', 'lai', 'dong', 'qi', 'chun', 'geng', 'ju', 'jue', 'yi', 'zun', 'ji',
  0x90 => 'shu', 'ying', 'chi', 'miao', 'rou', 'an', 'qiu', 'ti', 'hu', 'ti', 'e', 'jie', 'mao', 'fu', 'chun', 'tu',
  0xA0 => 'yan', 'he', 'yuan', 'pian', 'kun', 'mei', 'hu', 'ying', 'chuan', 'wu', 'ju', 'dong', 'cang', 'fang', 'he', 'ying',
  0xB0 => 'yuan', 'xian', 'weng', 'shi', 'he', 'chu', 'tang', 'xia', 'ruo', 'liu', 'ji', 'gu', 'jian', 'sun', 'han', 'ci',
  0xC0 => 'ci', 'yi', 'yao', 'yan', 'ji', 'li', 'tian', 'kou', 'ti', 'ti', 'yi', 'tu', 'ma', 'jiao', 'gao', 'tian',
  0xD0 => 'chen', 'ji', 'tuan', 'zhe', 'ao', 'yao', 'yi', 'ou', 'chi', 'zhi', 'liu', 'yong', 'lu', 'bi', 'shuang', 'zhuo',
  0xE0 => 'yu', 'wu', 'jue', 'yin', 'ti', 'si', 'jiao', 'yi', 'hua', 'bi', 'ying', 'su', 'huang', 'fan', 'jiao', 'liao',
  0xF0 => 'yan', 'gao', 'jiu', 'xian', 'xian', 'tu', 'mai', 'zun', 'yu', 'ying', 'lu', 'tuan', 'xian', 'xue', 'yi', 'pi',
];
